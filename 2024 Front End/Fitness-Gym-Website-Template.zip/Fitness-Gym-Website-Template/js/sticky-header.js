// JavaScript Document
 
  $(document).ready(function(){
  	"use strict";
	 if( $( window ).width() >= "768" ) {
		$(".header, .header-1").sticky({topSpacing:0});	
    }

  });
  $(document).ready(function(){
  	"use strict";
	 if( $( window ).width() >= "768" ) {
		$(".sub-nav").sticky({topSpacing:100});	
    }

  });
  