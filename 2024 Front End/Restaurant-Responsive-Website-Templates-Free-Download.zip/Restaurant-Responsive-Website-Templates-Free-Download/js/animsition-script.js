// JavaScript Document

 $(document).on('ready', function() {
    "use strict";
    	$('.animsition').animsition();
  });