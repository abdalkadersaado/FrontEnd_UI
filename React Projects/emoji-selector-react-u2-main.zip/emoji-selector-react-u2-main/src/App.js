import EmojiPickerInput from "./components/emojiPicker/emojiPickerInput";

function App() {
  return (
    <EmojiPickerInput />
  );
}

export default App;
