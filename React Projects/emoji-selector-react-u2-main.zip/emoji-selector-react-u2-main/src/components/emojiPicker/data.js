export const data = [
    {
        symbol: "😊",
        name: "cara alegre",
        keywords: "smiling face happy",
    },
    {
        symbol: "❤",
        name: "corazon",
        keywords: "hearth love like",
    },
    {
        symbol: "🔥",
        name: "fuego",
        keywords: "fire hot burn",
    },
    {
        symbol: "💎",
        name: "diamante",
        keywords: "gem stone diamond",
    },
    {
        symbol: "🤯",
        name: "cabeza explotada",
        keywords: "head exploding mind blowing",
    },
];