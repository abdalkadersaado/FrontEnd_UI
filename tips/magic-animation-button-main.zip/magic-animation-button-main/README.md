# Magic Animation Button
## [Watch it on youtube](https://youtu.be/vrt9o-O_JOo)
### Magic Animation Button

- Magic Button Hover Effects Animation Using HTML & CSS
- Contains geometric shapes with animation effects.
- Along with brilliant animation on the button.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
